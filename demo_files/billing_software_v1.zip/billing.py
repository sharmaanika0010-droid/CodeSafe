def total(items):
    return sum(i["price"]*i["qty"] for i in items)

print("Shree Infotech Billing Software v1.0")
